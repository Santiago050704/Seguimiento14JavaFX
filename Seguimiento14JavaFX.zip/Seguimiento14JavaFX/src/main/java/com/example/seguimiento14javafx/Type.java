package com.example.seguimiento14javafx;

public enum Type {
    INCOME, EXPENSE;
}
