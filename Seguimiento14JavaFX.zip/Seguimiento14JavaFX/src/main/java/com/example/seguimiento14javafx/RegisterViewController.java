package com.example.seguimiento14javafx;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;


public class RegisterViewController implements Initializable {

    @FXML
    private TextField amountTF;

    @FXML
    private TextField dateTF;

    @FXML
    private TextField descriptionTF;

    @FXML
    private AnchorPane registerAmountAP;

    @FXML
    private Button registerBtn;

    @FXML
    private Label registerLbl;

    @FXML
    private VBox registerVB;

    @FXML
    private ChoiceBox<Type> choiceTypeCB;

    @FXML
    private Button returnToWelcomeBtn1;

    @FXML
    private void registerButtonAction(ActionEvent event) throws IOException {
        double amount = Double.parseDouble(amountTF.getText());
        String description = descriptionTF.getText();
        Type type = choiceTypeCB.getValue();
        String dateStr = dateTF.getText();
        Date date = null;
        try{
            date = new SimpleDateFormat("yyyy-MM-dd").parse(dateStr);
        }catch (ParseException ex){
            ex.printStackTrace();
        }

        Registration newRegistration = new Registration(amount, description, type, date);
        RegisterList.getInstance().getContacts().add(newRegistration);

    }

    @FXML
    public void goToWelcomeActionBtn1(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("WelcomeView.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) returnToWelcomeBtn1.getScene().getWindow();
            stage.setScene(scene);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<Type> types = FXCollections.observableArrayList(Type.values());
        choiceTypeCB.setItems(types);
    }


}
