package com.example.seguimiento14javafx;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class RegisterList {

    private ObservableList<Registration> registers = FXCollections.observableArrayList();
    private RegisterList(){}

    private static RegisterList instance = null;

    public static RegisterList getInstance(){
        if(instance == null){
            instance = new RegisterList();
        }
        return instance;
    }

    public ObservableList<Registration> getContacts() {
        return registers;
    }

    public void setContacts(ObservableList<Registration> registers) {
        this.registers = registers;
    }
}



