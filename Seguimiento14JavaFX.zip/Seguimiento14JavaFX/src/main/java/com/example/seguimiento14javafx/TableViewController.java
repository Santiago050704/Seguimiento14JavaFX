package com.example.seguimiento14javafx;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.*;

public class TableViewController implements Initializable {
    @FXML
    private Button allBtn;

    @FXML
    private Button returnToWelcomeBtn2;

    @FXML
    private TableColumn<?, ?> amountCol;

    @FXML
    private TableColumn<?, ?> dateCol;

    @FXML
    private TableColumn<?, ?> descriptionCol;

    @FXML
    private Button expenseBtn;

    @FXML
    private Button incomeBtn;

    @FXML
    private TableView<Registration> tableView;

    @FXML
    private TableColumn<?, ?> typeCol;

    @FXML
    private AnchorPane viewLogsAP;




    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        amountCol.setCellValueFactory(new PropertyValueFactory<>("amount"));
        descriptionCol.setCellValueFactory(new PropertyValueFactory<>("description"));
        typeCol.setCellValueFactory(new PropertyValueFactory<>("type"));
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));

        tableView.setItems(RegisterList.getInstance().getContacts());

    }

    public ArrayList<Registration> getFilteredRegistrations(Type type){
        ArrayList<Registration> filteredList = new ArrayList<>();
        for(Registration registration : RegisterList.getInstance().getContacts()){
            if(registration.getType().equalsIgnoreCase(type.toString())){
                filteredList.add(registration);
            }
        }
        filteredList.sort(new Comparator<Registration>() {
            @Override
            public int compare(Registration r1, Registration r2) {
                return r2.getDate().compareTo(r1.getDate());
            }
        });
        return filteredList;
    }

    @FXML
    public void showIncomes(ActionEvent event){
        ArrayList<Registration> filteredList = getFilteredRegistrations(Type.INCOME);
        tableView.setItems(FXCollections.observableArrayList(filteredList));
    }

    @FXML
    public void showExpenses(ActionEvent event){
        ArrayList<Registration> filteredList = getFilteredRegistrations(Type.EXPENSE);
        tableView.setItems(FXCollections.observableArrayList(filteredList));
    }

    @FXML
    public void showAll(ActionEvent event){
        RegisterList.getInstance().getContacts().sort(new Comparator<Registration>() {
            @Override
            public int compare(Registration r1, Registration r2) {
                return r2.getDate().compareTo(r1.getDate());
            }
        });
        tableView.setItems(FXCollections.observableArrayList(RegisterList.getInstance().getContacts()));
    }

    @FXML
    public void goToWelcomeActionBtn2(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("WelcomeView.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) returnToWelcomeBtn2.getScene().getWindow();
            stage.setScene(scene);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
